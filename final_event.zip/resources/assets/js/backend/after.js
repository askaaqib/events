// Loaded after CoreUI app.js

var $ = require('jquery');

// const days_work= ['saturday', 'sunday', 'monday', 'tuesday', 'wednessday', 'thursday', 'friday'];

// $('#days_of_work').val(JSON.stringify(days_work))

// $(document).on('click','#saturday, #sunday, #monday, #tuesday, #wednessday, #thursday, #friday', function(){

// 	let selected_val = this.value;

// 	if(days_work.includes(selected_val)){
// 		days_work.splice( days_work.indexOf(selected_val), 1 );
// 	}else{
// 		days_work.push(selected_val)
// 	}

// 	$('#days_of_work').val(JSON.stringify(days_work))

// })